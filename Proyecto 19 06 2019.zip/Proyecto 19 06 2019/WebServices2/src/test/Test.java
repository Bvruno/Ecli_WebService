package test;

import conexion.ConexionBD;
import daos.UsuarioDAO;

public class Test {
	
	public static void main(String[] args) {
		
		ConexionBD.generarInstancia();
		String correo="ivan1@gmail.com";
		String clave="123456";
	    UsuarioDAO usuarioDAO = new UsuarioDAO();
		if (usuarioDAO.login(correo, clave)) {
			System.out.println("Login Correcto");
		} else {
          System.out.println("Login Incorrecto");
		}
		
		
	}

}
