package webservices;

import daos.UsuarioDAO;

public class Login {

	public boolean loginUser(String correo,String clave) {
		boolean result;
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		result = usuarioDAO.login(correo, clave);
		return result;
		
	}
	
	public boolean insertUser(String correo,String clave) {
		boolean result;
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		result = usuarioDAO.insertar(correo, clave);
		return result;
		
	}
	
	
	
}
