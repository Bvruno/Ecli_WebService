package webservices;

public class WebServiceOperaciones {
	
	public int sumaEnteros(int num1,int num2) {
		
		return num1 + num2;
		
		
	}
	
	public String restaEnteros(int num1,int num2) {
		int resta = num1 - num2;
		return "La diferencia de los n�meros es :"+resta;
		
	}
	
	public String calcularPago(String nombre, double precio, double descuento,int cantidad) {
		final double  IGV = 0.18;
		double pago = precio*cantidad - precio*descuento + precio*cantidad*IGV;
		return "El pago del cliente :"+nombre+"es :"+pago;
	}
	

}
