package daos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import conexion.ConexionBD;

public class UsuarioDAO {
	
	private static PreparedStatement pstm=null;
	private static ResultSet res =null;
	private static ConexionBD con= ConexionBD.generarInstancia();
    private static final String SQL_LOGIN="select * from usuario where correo=? and clave=? ";
    private static final String SQL_INSERT="insert into usuario values(?,?)";
    
	public boolean login(String correo,String clave) {
		boolean result = false;	
		try {
			pstm = con.getCon().prepareStatement(SQL_LOGIN);
			pstm.setString(1, correo );
			pstm.setString(2, clave);
			res = pstm.executeQuery();
			if(res.next()) {
				result=true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error login:"+e.getMessage());
			
		}
		finally {
			cerrarConexion();
		}
		
		return result;
		
	}
	
	public boolean insertar(String correo, String clave) {
		
		boolean result = false;
		try {
			pstm = con.getCon().prepareStatement(SQL_INSERT);
			pstm.setString(1, correo);
			pstm.setString(2, clave);
			if (pstm.executeUpdate()>0) {
				result =true;
			}
			
		} catch (Exception e) {
			
			System.out.println("Error :"+e.getMessage());
			e.printStackTrace();
			
		}
		finally {	
			cerrarConexion();
		}
		
		return result;
		
	}
	
	
	
	private void cerrarConexion() {
		
		try {
			if(res!=null)res.close();
			if(pstm!=null)pstm.close();
			if(con!=null)con.cerrarConexion();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	
	

}
