package com.ivan.webserviceclient;

import android.os.StrictMode;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

public class WSClient {

    public boolean Login(String correo, String clave) throws IOException, XmlPullParserException {

        boolean resultado = false;
       // Referenciando el targetnamespace y/o nombre del paquete y el metodo
        SoapObject soap = new SoapObject("http://webservices","loginUser");
        // Agregar los parametros:
        soap.addProperty("correo",correo);
        soap.addProperty("clave",clave);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(soap);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        HttpTransportSE http = new HttpTransportSE("http://172.17.35.25:8080/WebServices2/services/Login?wsdl");
        http.call("loginUser",envelope);
        Object respuesta = envelope.getResponse();
        if (respuesta.toString().equalsIgnoreCase("true")){
            resultado = true;
            return resultado;
        }
        else{
            return resultado;
        }
    }


}
