package com.ivan.webserviceclient;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button sincrono;
    private Button asincrono;
    private Handler handler = new Handler();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sincrono  = findViewById(R.id.btnSincrono);
        asincrono = findViewById(R.id.btnAsincrono);
        sincrono.setOnClickListener(this);
        asincrono.setOnClickListener(this);
    }

    private void unSegundo(){
        try {
            Thread.sleep(1000);
        }
        catch (Exception e){
            System.out.println("Error en el hilo :"+e.getMessage());
            e.printStackTrace();
        }
    }

    public void onClick(View view){

         switch (view.getId()){

             case R.id.btnSincrono:
             for (int i=0;i<10;i++){
                 unSegundo();
             }
             Toast.makeText(getBaseContext(),"Se libero el hilo principal",Toast.LENGTH_SHORT).show();
             break;

             case R.id.btnAsincrono:
                hilos();
             break;

         }

    }

    private void hilos(){

         new Thread(new Runnable() {
             @Override
             public void run() {
                 for (int i=0;i<10;i++){
                     unSegundo();
                 }
                 /*
                 handler.post(new Runnable() {
                     @Override
                     public void run() {
                        Toast.makeText(getBaseContext(),"Se terminio de ejecutare hilo secundario",Toast.LENGTH_SHORT).show();
                     }
                 });*/
                 runOnUiThread(new Runnable() {
                     @Override
                     public void run() {
                         Intent i = new Intent(MainActivity.this,LoginActivity.class);
                         startActivity(i);
                     }
                 });


             }
         }).start();
    }

}
