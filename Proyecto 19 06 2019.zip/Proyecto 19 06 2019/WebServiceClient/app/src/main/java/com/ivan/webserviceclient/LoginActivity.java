package com.ivan.webserviceclient;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity  implements  Runnable {

    private EditText correo;
    private EditText clave;
    private Button botonLogin;
    Handler handler = new Handler();
    Thread hiloT;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        correo = findViewById(R.id.txtCorreo);
        clave = findViewById(R.id.txtClave);
        botonLogin = findViewById(R.id.btnLogin);

        botonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hiloT = new Thread(LoginActivity.this);
                hiloT.start();
            }
        });

    }

    @Override
    public void run() {

          WSClient wsClient = new WSClient();
          final boolean respuesta;
          try {
              respuesta = wsClient.Login(correo.getText().toString(),clave.getText().toString());
              handler.post(new Runnable() {
                  @Override
                  public void run() {
                  if(respuesta){
                      Toast.makeText(getBaseContext(),"Usuario Correcto",Toast.LENGTH_SHORT).show();
                  }
                  else{
                      Toast.makeText(getBaseContext(),"Usuario Incorrecto",Toast.LENGTH_SHORT).show();
                  }
                  }
              });
          }
          catch (Exception e){
              System.out.println("Error al invocar el webservice :"+e.getMessage());
              e.printStackTrace();
          }




    }
}
